<?php
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['success'=>false,'message'=>'Invalid request.']); exit; }
$name=trim($_POST['name']??''); $phone=trim($_POST['phone']??''); $email=trim($_POST['email']??''); $country=trim($_POST['country']??''); $message=trim($_POST['message']??'');
if($name===''||$phone===''||$country===''){http_response_code(422);echo json_encode(['success'=>false,'message'=>'নাম, মোবাইল ও দেশ পূরণ করুন।'],JSON_UNESCAPED_UNICODE);exit;}
if($email!==''&&!filter_var($email,FILTER_VALIDATE_EMAIL)){http_response_code(422);echo json_encode(['success'=>false,'message'=>'সঠিক ইমেইল দিন।'],JSON_UNESCAPED_UNICODE);exit;}

$uploadDir=__DIR__.'/data/uploads'; if(!is_dir($uploadDir)) mkdir($uploadDir,0755,true);
$allowed=[
 'passport'=>['jpg','jpeg','png','pdf'],
 'cv'=>['pdf','doc','docx']
];
$files=[];
foreach($allowed as $field=>$exts){
  $files[$field]=null;
  if(isset($_FILES[$field]) && $_FILES[$field]['error']!==UPLOAD_ERR_NO_FILE){
    $f=$_FILES[$field];
    if($f['error']!==UPLOAD_ERR_OK){http_response_code(422);echo json_encode(['success'=>false,'message'=>($field==='passport'?'Passport':'CV').' upload failed.'],JSON_UNESCAPED_UNICODE);exit;}
    if($f['size']>5*1024*1024){http_response_code(422);echo json_encode(['success'=>false,'message'=>($field==='passport'?'Passport':'CV').' file must be 5MB or smaller.'],JSON_UNESCAPED_UNICODE);exit;}
    $ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION));
    if(!in_array($ext,$exts,true)){http_response_code(422);echo json_encode(['success'=>false,'message'=>($field==='passport'?'Passport':'CV').' file type is not allowed.'],JSON_UNESCAPED_UNICODE);exit;}
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $mimeOk=[
      'jpg'=>['image/jpeg'],'jpeg'=>['image/jpeg'],'png'=>['image/png'],'pdf'=>['application/pdf'],
      'doc'=>['application/msword','application/octet-stream'],'docx'=>['application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/zip','application/octet-stream']
    ];
    if(!in_array($mime,$mimeOk[$ext]??[],true)){http_response_code(422);echo json_encode(['success'=>false,'message'=>($field==='passport'?'Passport':'CV').' file content is invalid.'],JSON_UNESCAPED_UNICODE);exit;}
    $stored=bin2hex(random_bytes(16)).'.'.$ext;
    if(!move_uploaded_file($f['tmp_name'],$uploadDir.'/'.$stored)){http_response_code(500);echo json_encode(['success'=>false,'message'=>'File could not be saved.'],JSON_UNESCAPED_UNICODE);exit;}
    $files[$field]=['path'=>'data/uploads/'.$stored,'name'=>mb_substr(basename($f['name']),0,150)];
  }
}

$dir=__DIR__.'/data'; if(!is_dir($dir)) mkdir($dir,0755,true); $file=$dir.'/applications.json';
$items=[]; if(is_file($file)){ $raw=file_get_contents($file); $items=json_decode($raw,true) ?: []; }
$items[]=['id'=>uniqid('APP-',true),'name'=>mb_substr($name,0,100),'phone'=>mb_substr($phone,0,30),'email'=>mb_substr($email,0,120),'country'=>mb_substr($country,0,50),'message'=>mb_substr($message,0,2000),'passport'=>$files['passport'],'cv'=>$files['cv'],'status'=>'নতুন','created_at'=>date('Y-m-d H:i:s')];
file_put_contents($file,json_encode($items,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT),LOCK_EX); echo json_encode(['success'=>true,'message'=>'আপনার আবেদন সফলভাবে গ্রহণ করা হয়েছে। আমাদের টিম যোগাযোগ করবে।'],JSON_UNESCAPED_UNICODE);
