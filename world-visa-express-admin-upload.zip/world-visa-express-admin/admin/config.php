<?php
// Change this password before going live. Default: admin12345
const ADMIN_USER = 'admin';
const ADMIN_PASSWORD_HASH = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC6aR1wQ9h7zQm2n8m2G';
