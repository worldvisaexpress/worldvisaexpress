<?php
require_once __DIR__.'/auth.php'; require_login();
$id=$_GET['id']??''; $type=$_GET['type']??'';
if(!in_array($type,['passport','cv'],true) || $id===''){http_response_code(400);exit('Invalid request.');}
$file=__DIR__.'/../data/applications.json'; $items=is_file($file)?(json_decode(file_get_contents($file),true)?:[]):[]; $found=null;
foreach($items as $x){if(($x['id']??'')===$id){$found=$x;break;}}
$doc=$found[$type]??null;
if(!is_array($doc) || empty($doc['path'])){http_response_code(404);exit('File not found.');}
$base=realpath(__DIR__.'/../data/uploads'); $path=realpath(__DIR__.'/../'.$doc['path']);
if(!$base || !$path || strpos($path,$base.DIRECTORY_SEPARATOR)!==0 || !is_file($path)){http_response_code(404);exit('File not found.');}
$name=preg_replace('/[^A-Za-z0-9._ -]/','_',basename($doc['name']??basename($path))); $mime=(new finfo(FILEINFO_MIME_TYPE))->file($path) ?: 'application/octet-stream';
header('Content-Type: '.$mime); header('Content-Length: '.filesize($path)); header('Content-Disposition: attachment; filename="'.$name.'"'); readfile($path);
