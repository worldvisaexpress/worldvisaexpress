<?php
require_once __DIR__.'/auth.php';
require_login();

$error = '';
$success = '';

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $error = 'অনুরোধটি নিরাপদ নয়। আবার চেষ্টা করুন।';
    } else {
        $current = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if (!password_verify($current, ADMIN_PASSWORD_HASH)) {
            $error = 'বর্তমান পাসওয়ার্ড সঠিক নয়।';
        } elseif (strlen($new) < 8) {
            $error = 'নতুন পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে।';
        } elseif ($new !== $confirm) {
            $error = 'নতুন পাসওয়ার্ড এবং নিশ্চিত পাসওয়ার্ড মিলছে না।';
        } elseif ($new === $current) {
            $error = 'নতুন পাসওয়ার্ডটি বর্তমান পাসওয়ার্ড থেকে আলাদা দিন।';
        } else {
            $configFile = __DIR__.'/config.php';
            $config = "<?php\n// Admin username and password are managed from the Admin Panel.\nconst ADMIN_USER = '" . addslashes(ADMIN_USER) . "';\nconst ADMIN_PASSWORD_HASH = '" . password_hash($new, PASSWORD_DEFAULT) . "';\n";
            $tmp = $configFile . '.tmp';

            if (@file_put_contents($tmp, $config, LOCK_EX) === false || !@rename($tmp, $configFile)) {
                @unlink($tmp);
                $error = 'পাসওয়ার্ড সংরক্ষণ করা যায়নি। admin/config.php ফাইলটি writable আছে কি না দেখুন।';
            } else {
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                $success = 'পাসওয়ার্ড সফলভাবে পরিবর্তন হয়েছে। এখন থেকে নতুন পাসওয়ার্ড দিয়ে লগইন করবেন।';
            }
        }
    }
}
?>
<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Change Password - WORLD VISA Express</title>
<link rel="stylesheet" href="admin.css">
</head>
<body>
<div class="login-card">
<img src="../world-visa-express-logo.png" alt="WORLD VISA Express">
<h1>WORLD VISA Express</h1>
<h2>পাসওয়ার্ড পরিবর্তন</h2>
<?php if ($error): ?><div class="error"><?=htmlspecialchars($error)?></div><?php endif; ?>
<?php if ($success): ?><div class="success"><?=htmlspecialchars($success)?></div><?php endif; ?>
<form method="post" autocomplete="off">
<input type="hidden" name="csrf_token" value="<?=htmlspecialchars($_SESSION['csrf_token'])?>">
<label>বর্তমান পাসওয়ার্ড</label>
<input type="password" name="current_password" required autocomplete="current-password">
<label>নতুন পাসওয়ার্ড</label>
<input type="password" name="new_password" minlength="8" required autocomplete="new-password">
<label>নতুন পাসওয়ার্ড আবার লিখুন</label>
<input type="password" name="confirm_password" minlength="8" required autocomplete="new-password">
<button>পাসওয়ার্ড পরিবর্তন করুন</button>
</form>
<a href="index.php">← Admin Panel</a> &nbsp; <a href="logout.php">Logout</a>
</div>
</body>
</html>
