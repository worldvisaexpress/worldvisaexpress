WORLD VISA Express Admin Panel

Features:
- Admin login and password change
- Online application storage
- Passport upload (JPG/JPEG/PNG/PDF, max 5MB)
- CV upload (PDF/DOC/DOCX, max 5MB)
- Admin-only authenticated download of uploaded documents
- Application status update and delete

Important: Use HTTPS and change the default admin password before going live. Uploaded files are protected from direct web access and are served through the authenticated admin download endpoint.
